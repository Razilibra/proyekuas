<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('mahasiswa_pkl_nilai', function (Blueprint $table) {
            $table->id('id_mahasiswa_pkl_nilai');
            $table->unsignedBigInteger('id_mahasiswa_pkl')->nullable();
            $table->unsignedBigInteger('id_dosen')->nullable();
            $table->unsignedBigInteger('id_mahasiswa_pkl_point_penguji')->nullable();
            $table->timestamps();

            $table->foreign('id_mahasiswa_pkl')->references('id_mahasiswa_pkl')->on('mahasiswa_pkl')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('id_mahasiswa_pkl_point_penguji')->references('id_mahasiswa_pkl_point_penguji')->on('mahasiswa_pkl_point_penguji')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('id_dosen')->references('id_dosen')->on('dosen')->onDelete('cascade')->onUpdate('cascade');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('mahasiswa_pkl_nilai');
    }
};
